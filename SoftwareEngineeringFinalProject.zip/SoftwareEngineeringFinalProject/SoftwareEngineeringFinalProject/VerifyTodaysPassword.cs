﻿using System;

public class VerifyTodaysPassword
{
    bool handler; //determines if the information given matches the information requested

    public VerifyTodaysPassword(string pw) //determines if the information is different from the information given
    {

	}

    public bool isTodaysPasswordCorrect(string passwordFromClient)
    {

    }

}
