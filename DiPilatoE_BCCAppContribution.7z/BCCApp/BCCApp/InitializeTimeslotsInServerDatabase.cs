﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCCApp
{
    class InitializeTimeslotsInServerDatabase
    {
        public InitializeTimeslotsInServerDatabase(String startTime, String endTime)
        //This is the constructor method
        {
            if (validateStringInput(startTime) && validateStringInput(endTime))
                storeTimeslotToDatabase(startTime, endTime);
        }
        private void storeTimeslotToDatabase(String startTime, String endTime)
        //This method stores the start and end times for a timeslot to the Timeslots table in the database
        {

        }
        private bool validateStringInput(String someString)
        //This method validates the strings given to the class to protect against sql injection
        {
            int ignoreMe;
            return Int32.TryParse(someString, out ignoreMe);
        }
    }
}
