﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Data;
using System.Data.SqlClient;

namespace BCCApp
{
    class InitializeCountsInServerDatabase
    {
        public InitializeCountsInServerDatabase()
        //This is the constructor method
        {
            initializeCountsInDatabase();
        }
        private void initializeCountsInDatabase()
        //This function initializes the fields of the counts table of the Database to a value of -1
        //The number of counts rows initialized equals the number of timeslots time the number of rooms
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = "Server=WITPF0TX5EG;Database=BCCHeadcounts;Trusted_Connection=true";
                connection.Open();
                SqlCommand numberOfRooms = new SqlCommand("SELECT COUNT(RoomUID) FROM Rooms", connection);
                SqlCommand numberOfTimeslots = new SqlCommand("SELECT COUNT(TimeSlotUID) FROM TimeSlots", connection);
                for (int x = 0; x++; x < )
                {
                    SqlCommand initializeCounts = new SqlCommand("UPDATE Counts SET ", connection);
                }
            }
        }
    }
}
