﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCCApp
{
    class InitializeRoomsInServerDatabase
    {
        public InitializeRoomsInServerDatabase(String room, String roomCapacity)
        //This is the constructor method
        {
            if (validateStringInput(room))
                storeRoomToDatabase(room);
            if (validateStringInput(roomCapacity))
                storeRoomCapcityToDatabase(roomCapacity);
        }
        private void storeRoomToDatabase(String room)
        //This method stores the room name, given by the server UI, to the Rooms table in the database
        {

        }
        private void storeRoomCapcityToDatabase(String roomCapacity)
        //This method stores the room capacity, given by the server UI, to the Rooms table in the database
        {

        }
        private bool validateStringInput(String someString)
        //This method validates the strings given to the class to protect against sql injection
        {

        }
    }
}
