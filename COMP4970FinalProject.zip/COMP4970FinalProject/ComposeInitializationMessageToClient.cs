﻿using System;

public class ComposeInitializationMessageToClient
{
    String message; //The message composed by the server

    public ComposeInitializationMessageToClient() //composes the initialization message for the client to read
    {   
        
	}

    private void addPasswordToMessage() //adds the entered password to the message
    {

    }

    private void addDeliniatorToMessage() //adds the signals to determine what information to search
    {

    }

    private void addAllRoomsToMessage() //adds all the rooms being checked to the message
    {

    }

    private void addAllTimeslotsToMessage() //adds all timeslots being checked to the handler
    {

    }

    private void sendMessageToTCP() //sends the final message to the TCP
    {

    }
}
