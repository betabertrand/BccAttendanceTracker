﻿using System;

public class HandleDiscrepency
{
    bool handler; //determines if the information given matches the information requested

    public HandleDiscrepency() //determines if the information is different from the information given
    {

	}

    private int setCounterToZero() //sets the counter of mismatched information to zero
    {

    }

    private void addPasswordToHandler() //separates any passwords for the given information
    {

    }

    private void addDeliniatorToHandler() //adds the signals to determine what information to search
    {

    }

    private void addAllRoomsToHandler() //adds all the rooms being checked to the handler
    {

    }

    private void addAllTimeslotsToHandler() //adds all timeslots being checked to the handler
    {

    }

    private void storeOldCounterData() //when the counter increases, takes the old value for reference
    {

    }

    private bool increaseCounter() //increases the discrepency counter where needed
    {

    }
}
